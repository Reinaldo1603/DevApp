# DevApp Studio
Landing page PWA estática. Arquivos: index.html, politicas.html, manifest.json, sw.js, icons/.
## Publicar no GitHub Pages
1. Crie o repositório e envie todos os arquivos na raiz.
2. Settings > Pages > Deploy from a branch > main / (root).
3. Acesse https://SEU-USUARIO.github.io/NOME-DO-REPO/
Antes: troque WA no index.html (número do WhatsApp), e-mail e dados [ENTRE COLCHETES] em politicas.html.
